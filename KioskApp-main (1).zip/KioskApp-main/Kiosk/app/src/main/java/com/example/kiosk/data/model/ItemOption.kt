package com.example.kiosk.data.model

data class ItemOption(
    val name: String,
    val price: Int = 0
)
